#include "bluetoothmanager.h"
#include <QDebug>

BluetoothManager::BluetoothManager(QObject *parent) : QObject(parent),
    scanning(false)
{
    // 初始化本地蓝牙设备
    localDevice = new QBluetoothLocalDevice(this);

    // 确保蓝牙已开启
    if (localDevice->isValid()) {
        localDevice->powerOn();
    }

    // 初始化设备发现代理
    discoveryAgent = new QBluetoothDeviceDiscoveryAgent(this);
    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered,
            this, &BluetoothManager::onDeviceDiscovered);
    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::finished,
            this, &BluetoothManager::onScanFinished);

    // 初始化蓝牙socket
    socket = new QBluetoothSocket(QBluetoothServiceInfo::RfcommProtocol, this);
    connect(socket, &QBluetoothSocket::connected,
            this, &BluetoothManager::onSocketConnected);
    connect(socket, &QBluetoothSocket::disconnected,
            this, &BluetoothManager::onSocketDisconnected);
    connect(socket, QOverload<QBluetoothSocket::SocketError>::of(&QBluetoothSocket::error),
            this, &BluetoothManager::onSocketError);
    connect(socket, &QBluetoothSocket::readyRead,
            this, &BluetoothManager::onReadyRead);
}

BluetoothManager::~BluetoothManager()
{
    stopScan();
    disconnectFromDevice();
    delete socket;
    delete discoveryAgent;
    delete localDevice;
}

void BluetoothManager::startScan()
{
    if (!scanning) {
        discoveryAgent->start();
        scanning = true;
    }
}

void BluetoothManager::stopScan()
{
    if (scanning) {
        discoveryAgent->stop();
        scanning = false;
    }
}

bool BluetoothManager::connectToDevice(const QString &address)
{
    // 如果已连接则先断开
    if (socket->state() == QBluetoothSocket::ConnectedState) {
        disconnectFromDevice();
    }

    // 连接到设备
    QBluetoothAddress bluetoothAddress(address);
    socket->connectToService(bluetoothAddress, QBluetoothUuid::SerialPort);
    return true;
}

void BluetoothManager::disconnectFromDevice()
{
    if (socket->state() == QBluetoothSocket::ConnectedState) {
        socket->disconnectFromService();
    }
}

bool BluetoothManager::sendData(const QString &data)
{
    if (socket->state() == QBluetoothSocket::ConnectedState) {
        QByteArray byteArray = data.toUtf8();
        socket->write(byteArray);
        return socket->waitForBytesWritten();
    }
    return false;
}

bool BluetoothManager::isConnected() const
{
    return socket->state() == QBluetoothSocket::ConnectedState;
}

void BluetoothManager::onDeviceDiscovered(const QBluetoothDeviceInfo &device)
{
    emit deviceDiscovered(device);
}

void BluetoothManager::onScanFinished()
{
    scanning = false;
    emit scanFinished();
}

void BluetoothManager::onSocketConnected()
{
    emit connected();
}

void BluetoothManager::onSocketDisconnected()
{
    emit disconnected();
}

void BluetoothManager::onSocketError(QBluetoothSocket::SocketError error)
{
    QString errorString;
    switch (error) {
    case QBluetoothSocket::UnknownError:
        errorString = "未知错误";
        break;
    case QBluetoothSocket::HostNotFoundError:
        errorString = "未找到设备";
        break;
    case QBluetoothSocket::ConnectionRefusedError:
        errorString = "连接被拒绝";
        break;
    case QBluetoothSocket::RemoteHostClosedError:
        errorString = "远程主机已关闭连接";
        break;
    default:
        errorString = socket->errorString();
    }
    emit errorOccurred(errorString);
}

void BluetoothManager::onReadyRead()
{
    QByteArray data = socket->readAll();
    emit dataReceived(QString::fromUtf8(data));
}
