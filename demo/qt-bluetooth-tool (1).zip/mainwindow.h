#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QBluetoothDeviceInfo>
#include "bluetoothmanager.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_scanButton_clicked();
    void on_connectButton_clicked();
    void on_sendButton_clicked();
    void on_clearButton_clicked();
    void on_disconnectButton_clicked();

    // 蓝牙相关槽函数
    void addDevice(const QBluetoothDeviceInfo &device);
    void deviceConnected();
    void deviceDisconnected();
    void dataReceived(const QString &data);
    void connectionError(const QString &error);
    void scanFinished();

private:
    Ui::MainWindow *ui;
    BluetoothManager *bluetoothManager;
    bool isScanning;
};

#endif // MAINWINDOW_H
