#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    isScanning(false)
{
    ui->setupUi(this);
    setWindowTitle("蓝牙收发工具");

    // 初始化蓝牙管理器
    bluetoothManager = new BluetoothManager(this);

    // 连接信号槽
    connect(bluetoothManager, &BluetoothManager::deviceDiscovered,
            this, &MainWindow::addDevice);
    connect(bluetoothManager, &BluetoothManager::connected,
            this, &MainWindow::deviceConnected);
    connect(bluetoothManager, &BluetoothManager::disconnected,
            this, &MainWindow::deviceDisconnected);
    connect(bluetoothManager, &BluetoothManager::dataReceived,
            this, &MainWindow::dataReceived);
    connect(bluetoothManager, &BluetoothManager::errorOccurred,
            this, &MainWindow::connectionError);
    connect(bluetoothManager, &BluetoothManager::scanFinished,
            this, &MainWindow::scanFinished);

    // 初始化UI状态
    ui->connectButton->setEnabled(false);
    ui->disconnectButton->setEnabled(false);
    ui->sendButton->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_scanButton_clicked()
{
    if (!isScanning) {
        // 开始扫描
        ui->deviceListWidget->clear();
        bluetoothManager->startScan();
        ui->scanButton->setText("停止扫描");
        isScanning = true;
        ui->statusBar->showMessage("正在扫描蓝牙设备...");
    } else {
        // 停止扫描
        bluetoothManager->stopScan();
        ui->scanButton->setText("扫描设备");
        isScanning = false;
        ui->statusBar->showMessage("扫描已停止");
    }
}

void MainWindow::on_connectButton_clicked()
{
    QListWidgetItem *item = ui->deviceListWidget->currentItem();
    if (!item) {
        QMessageBox::warning(this, "警告", "请先选择一个设备");
        return;
    }

    QString address = item->data(Qt::UserRole).toString();
    bluetoothManager->connectToDevice(address);
    ui->statusBar->showMessage("正在连接到设备...");
}

void MainWindow::on_sendButton_clicked()
{
    QString data = ui->sendTextEdit->toPlainText();
    if (data.isEmpty()) {
        QMessageBox::warning(this, "警告", "发送内容不能为空");
        return;
    }

    if (bluetoothManager->sendData(data)) {
        // 在接收区显示发送的内容
        QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        ui->receiveTextEdit->append(QString("[%1] 发送: %2").arg(time).arg(data));
        ui->sendTextEdit->clear();
    } else {
        QMessageBox::warning(this, "发送失败", "无法发送数据，请检查连接");
    }
}

void MainWindow::on_clearButton_clicked()
{
    ui->receiveTextEdit->clear();
}

void MainWindow::on_disconnectButton_clicked()
{
    bluetoothManager->disconnectFromDevice();
}

void MainWindow::addDevice(const QBluetoothDeviceInfo &device)
{
    // 只添加经典蓝牙设备
    if (device.coreConfigurations() & QBluetoothDeviceInfo::ClassicBluetooth) {
        QString name = device.name();
        QString address = device.address().toString();

        if (name.isEmpty()) {
            name = "未知设备";
        }

        QListWidgetItem *item = new QListWidgetItem(QString("%1 (%2)").arg(name).arg(address));
        item->setData(Qt::UserRole, address);
        ui->deviceListWidget->addItem(item);
    }
}

void MainWindow::deviceConnected()
{
    ui->statusBar->showMessage("设备已连接");
    ui->connectButton->setEnabled(false);
    ui->disconnectButton->setEnabled(true);
    ui->sendButton->setEnabled(true);
    ui->scanButton->setEnabled(false);
}

void MainWindow::deviceDisconnected()
{
    ui->statusBar->showMessage("设备已断开连接");
    ui->connectButton->setEnabled(true);
    ui->disconnectButton->setEnabled(false);
    ui->sendButton->setEnabled(false);
    ui->scanButton->setEnabled(true);
}

void MainWindow::dataReceived(const QString &data)
{
    QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    ui->receiveTextEdit->append(QString("[%1] 接收: %2").arg(time).arg(data));
}

void MainWindow::connectionError(const QString &error)
{
    QMessageBox::critical(this, "连接错误", error);
    ui->statusBar->showMessage("连接失败: " + error);
}

void MainWindow::scanFinished()
{
    ui->scanButton->setText("扫描设备");
    isScanning = false;
    ui->statusBar->showMessage(QString("扫描完成，共发现 %1 个设备").arg(ui->deviceListWidget->count()));
    ui->connectButton->setEnabled(ui->deviceListWidget->count() > 0);
}
