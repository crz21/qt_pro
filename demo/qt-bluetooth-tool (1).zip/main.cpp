#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    // 确保应用程序支持中文显示
    QFont font("SimHei");
    a.setFont(font);
    
    MainWindow w;
    w.show();

    return a.exec();
}
