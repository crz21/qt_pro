QT       += core gui bluetooth

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = BluetoothTool
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    bluetoothmanager.cpp

HEADERS += \
    mainwindow.h \
    bluetoothmanager.h

FORMS += \
    mainwindow.ui

# Windows-specific configuration
win32 {
    LIBS += -lBthprops.lib
    QMAKE_CXXFLAGS += -DWIN32
}
